# CountDown Timer using Python Tkinter


Minor Project Statement : Create A Countdown Timer Using Python
Features Included :
Start
Reset 
Pause 
Resume
Quit

